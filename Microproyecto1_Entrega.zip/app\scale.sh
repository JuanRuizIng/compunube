#!/bin/bash
# ==============================================================================
# Script: scale.sh
# Descripción: Escala horizontalmente la aplicación Node.js usando PM2
#              y registra dinámicamente cada instancia en Consul.
# Uso:
#   bash scale.sh <numero_de_instancias>
# Ejemplo:
#   bash scale.sh 3
# ==============================================================================

INSTANCIAS=$1
if [ -z "$INSTANCIAS" ]; then
    echo "Error: Debe especificar el número de instancias deseado."
    echo "Uso: bash scale.sh <numero_de_instancias>"
    echo "Ejemplo: bash scale.sh 3"
    exit 1
fi

HOSTNAME=$(hostname)
LOCAL_IP=$(hostname -I | awk '{print $2}')
# Si la IP secundaria no existe, tomar la primaria
if [ -z "$LOCAL_IP" ]; then
    LOCAL_IP=$(hostname -I | awk '{print $1}')
fi

echo "=> Limpiando instancias y registros previos de Consul..."
# Detener y eliminar procesos previos de PM2
pm2 delete all 2>/dev/null

# Des-registrar servicios del rango de puertos 3000 al 3020 en Consul
for port in {3000..3020}; do
  curl -s --request PUT "http://127.0.0.1:8500/v1/agent/service/deregister/web-${HOSTNAME}-${port}" >/dev/null
done

echo "=> Levantando $INSTANCIAS instancia(s) de la aplicación en $HOSTNAME ($LOCAL_IP)..."
BASE_PORT=3000

for (( i=0; i<$INSTANCIAS; i++ ))
do
    PORT=$((BASE_PORT + i))
    SERVICE_ID="web-${HOSTNAME}-${PORT}"

    # 1. Iniciar instancia en PM2 con variable de entorno PORT
    PORT=$PORT pm2 start index.js --name "$SERVICE_ID"

    # 2. Registrar el servicio en Consul dinámicamente mediante la API HTTP
    PAYLOAD=$(cat <<EOF
{
  "ID": "${SERVICE_ID}",
  "Name": "web",
  "Tags": ["nodejs", "web", "app"],
  "Address": "${LOCAL_IP}",
  "Port": ${PORT},
  "Check": {
    "HTTP": "http://${LOCAL_IP}:${PORT}/health",
    "Interval": "10s",
    "Timeout": "2s"
  }
}
EOF
)
    curl -s --request PUT --data "$PAYLOAD" http://127.0.0.1:8500/v1/agent/service/register
    echo "  [✓] Instancia registrada: $SERVICE_ID en http://${LOCAL_IP}:${PORT}"
done

# Guardar estado de PM2
pm2 save >/dev/null 2>&1

echo "=> ¡Escalado a $INSTANCIAS instancia(s) completado con éxito!"
