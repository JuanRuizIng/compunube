#!/bin/bash
# ==============================================================================
# Script: setup_nodejs.sh
# Descripción: Instala Node.js, PM2, despliega la app e inicia la primera instancia.
# ==============================================================================

echo "=> Configurando DNS y asegurando conectividad..."
echo "nameserver 8.8.8.8" >> /etc/resolv.conf
echo "nameserver 1.1.1.1" >> /etc/resolv.conf

echo "=> Instalando Node.js 20.x LTS y PM2..."
export DEBIAN_FRONTEND=noninteractive
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs
npm install -g pm2

echo "=> Configurando el directorio de la aplicación..."
mkdir -p /home/vagrant/app
cp -r /vagrant/app/* /home/vagrant/app/
chown -R vagrant:vagrant /home/vagrant/app

echo "=> Instalando dependencias de Node.js (Express)..."
cd /home/vagrant/app
npm install

echo "=> Iniciando la primera instancia de la aplicación..."
su - vagrant -c "cd /home/vagrant/app && bash scale.sh 1"
su - vagrant -c "pm2 save"

# Configurar PM2 para iniciar automáticamente con el sistema
pm2 startup systemd -u vagrant --hp /home/vagrant
su - vagrant -c "pm2 save"

echo "=> Entorno Node.js listo y aplicación en ejecución."
