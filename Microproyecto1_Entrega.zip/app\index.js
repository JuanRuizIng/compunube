const express = require('express');
const os = require('os');
const app = express();

const PORT = process.env.PORT || 3000;
const HOSTNAME = os.hostname();

// Ruta principal para atender peticiones balanceadas
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="es">
      <head>
        <meta charset="utf-8">
        <title>Microproyecto 1 - Computación en la Nube</title>
        <style>
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            text-align: center;
            margin-top: 50px;
            background-color: #f7f9fc;
            color: #333;
          }
          .card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            display: inline-block;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            min-width: 320px;
          }
          h2 { color: #2e7d32; margin-top: 0; }
          .info { font-size: 18px; margin: 10px 0; }
          .highlight { font-weight: bold; color: #1565c0; }
        </style>
      </head>
      <body>
        <div class="card">
          <h2>🚀 ¡Petición Atendida con Éxito!</h2>
          <p class="info">Servidor: <span class="highlight">${HOSTNAME}</span></p>
          <p class="info">Puerto Local: <span class="highlight">${PORT}</span></p>
        </div>
      </body>
    </html>
  `);
});

// Endpoint de Health Check para el Service Mesh de Consul
app.get('/health', (req, res) => {
  res.status(200).send('OK');
});

app.listen(PORT, () => {
  console.log(`Servidor Node.js escuchando en el puerto ${PORT}`);
});
