#!/bin/bash
# ==============================================================================
# Script: install_consul.sh
# Descripción: Instala y configura HashiCorp Consul como servicio Systemd
# Argumentos:
#   $1 - Modo: "server" o "client"
#   $2 - IP del nodo en la red privada (ej. 192.168.100.20)
# ==============================================================================

MODE=$1
NODE_IP=$2

echo "=> Instalando dependencias base..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y wget unzip curl jq

echo "=> Descargando e instalando HashiCorp Consul 1.18.0..."
if [ ! -f /usr/local/bin/consul ]; then
  wget -q https://releases.hashicorp.com/consul/1.18.0/consul_1.18.0_linux_amd64.zip
  unzip consul_1.18.0_linux_amd64.zip
  mv consul /usr/local/bin/
  rm consul_1.18.0_linux_amd64.zip
fi

echo "=> Creando directorios para Consul..."
mkdir -p /etc/consul.d
mkdir -p /opt/consul
chown -R vagrant:vagrant /etc/consul.d /opt/consul

# Limpiar configuración previa si existe
rm -f /etc/consul.d/consul.json

echo "=> Generando configuración de Consul (Modo: $MODE)..."
if [ "$MODE" == "server" ]; then
  cat <<EOF > /etc/consul.d/consul.json
{
  "server": true,
  "node_name": "$(hostname)",
  "datacenter": "dc1",
  "data_dir": "/opt/consul",
  "bind_addr": "$NODE_IP",
  "client_addr": "0.0.0.0",
  "bootstrap_expect": 1,
  "ui_config": {
    "enabled": true
  }
}
EOF
else
  cat <<EOF > /etc/consul.d/consul.json
{
  "server": false,
  "node_name": "$(hostname)",
  "datacenter": "dc1",
  "data_dir": "/opt/consul",
  "bind_addr": "$NODE_IP",
  "client_addr": "0.0.0.0",
  "retry_join": ["192.168.100.20"]
}
EOF
fi

echo "=> Creando servicio Systemd para Consul..."
cat <<EOF > /etc/systemd/system/consul.service
[Unit]
Description=Consul Service Discovery Agent
Requires=network-online.target
After=network-online.target

[Service]
User=root
Group=root
ExecStart=/usr/local/bin/consul agent -config-dir=/etc/consul.d/
ExecReload=/bin/kill -HUP \$MAINPID
KillSignal=SIGINT
Restart=on-failure
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable consul
systemctl restart consul

echo "=> HashiCorp Consul instalado y activo en modo $MODE."
