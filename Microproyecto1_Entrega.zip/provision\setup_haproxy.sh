#!/bin/bash
# ==============================================================================
# Script: setup_haproxy.sh
# Descripción: Instala HAProxy, Consul-Template, página de error 503 personalizada
#              y configura el servicio dinámico de balanceo de carga.
# ==============================================================================

export DEBIAN_FRONTEND=noninteractive

echo "=> Instalando HAProxy..."
apt-get update -y
apt-get install -y haproxy

echo "=> Descargando e instalando Consul-Template 0.37.0..."
if [ ! -f /usr/local/bin/consul-template ]; then
  wget -q https://releases.hashicorp.com/consul-template/0.37.0/consul-template_0.37.0_linux_amd64.zip
  unzip consul-template_0.37.0_linux_amd64.zip
  mv consul-template /usr/local/bin/
  rm consul-template_0.37.0_linux_amd64.zip
fi

echo "=> Creando página de error 503 personalizada..."
mkdir -p /etc/haproxy/errors
cat <<EOF > /etc/haproxy/errors/503.http
HTTP/1.0 503 Service Unavailable
Cache-Control: no-cache
Connection: close
Content-Type: text/html; charset=utf-8

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>503 - Servicio No Disponible</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      text-align: center;
      margin-top: 60px;
      background-color: #f0f2f5;
      color: #333;
    }
    .container {
      background: #ffffff;
      padding: 40px;
      border-radius: 12px;
      display: inline-block;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      max-width: 550px;
    }
    h1 { color: #d32f2f; margin-bottom: 10px; font-size: 28px; }
    p { font-size: 16px; line-height: 1.6; color: #555; }
    .badge {
      display: inline-block;
      background: #ffebee;
      color: #c62828;
      padding: 6px 12px;
      border-radius: 6px;
      font-weight: bold;
      margin-top: 15px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>⚠️ Lo sentimos, servicio no disponible</h1>
    <p>El balanceador de carga (HAProxy) no ha encontrado ninguna instancia web activa en el clúster de Consul.</p>
    <p>Por favor, intente nuevamente en unos momentos o verifique el estado de los servidores.</p>
    <div class="badge">HTTP 503 Service Unavailable</div>
  </div>
</body>
</html>
EOF

echo "=> Configurando plantilla de Consul-Template para HAProxy..."
mkdir -p /etc/consul-template.d
cat <<'EOF' > /etc/consul-template.d/haproxy.ctmpl
global
    log /dev/log local0
    log /dev/log local1 notice
    chroot /var/lib/haproxy
    stats socket /run/haproxy/admin.sock mode 660 level admin expose-fd listeners
    stats timeout 30s
    user haproxy
    group haproxy
    daemon

defaults
    log     global
    mode    http
    option  httplog
    option  dontlognull
    timeout connect 5000
    timeout client  50000
    timeout server  50000
    errorfile 503 /etc/haproxy/errors/503.http

frontend http_front
    bind *:80
    default_backend web_backend

backend web_backend
    balance roundrobin{{range service "web"}}
    server {{.Node}}-{{.Port}} {{.Address}}:{{.Port}} check{{end}}

listen stats
    bind *:8404
    stats enable
    stats uri /stats
    stats refresh 5s
EOF

echo "=> Creando servicio Systemd para Consul-Template..."
cat <<EOF > /etc/systemd/system/consul-template.service
[Unit]
Description=Consul-Template for HAProxy
Requires=network-online.target
After=network-online.target consul.service

[Service]
User=root
Group=root
ExecStart=/usr/local/bin/consul-template -consul-addr=127.0.0.1:8500 -template="/etc/consul-template.d/haproxy.ctmpl:/etc/haproxy/haproxy.cfg:systemctl reload haproxy"
KillSignal=SIGINT
Restart=on-failure

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable consul-template
systemctl start consul-template

echo "=> HAProxy y Consul-Template aprovisionados correctamente."
