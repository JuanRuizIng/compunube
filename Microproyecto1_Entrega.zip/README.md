# Microproyecto 1: Cluster Consul + HAProxy + Artillery

Este proyecto implementa una infraestructura de alta disponibilidad y escalabilidad horizontal usando **HashiCorp Consul** (Service Discovery), **HAProxy + Consul-Template** (Balanceador de carga dinámico) y **Node.js** sobre máquinas virtuales gestionadas con **Vagrant**.

---

## 🏗️ Topología del Clúster

| Máquina Virtual | IP Privada | Servicios y Funciones |
| :--- | :--- | :--- |
| **`haproxy`** | `192.168.100.20` | - **Consul Server** (Líder del clúster con Web UI en `:8500`)<br>- **HAProxy** (Balanceador en puerto `:80`, Estadísticas en `:8404`)<br>- **Consul-Template** (Actualización en caliente de `haproxy.cfg`) |
| **`web1`** | `192.168.100.21` | - **Consul Client Agent**<br>- Servidor web Node.js gestionado con PM2 |
| **`web2`** | `192.168.100.22` | - **Consul Client Agent**<br>- Servidor web Node.js gestionado con PM2 |

---

## 🚀 Despliegue Paso a Paso

### 1. Iniciar las Máquinas Virtuales
Desde esta carpeta raíz, ejecuta:
```bash
vagrant up
```
*Vagrant descargará la imagen `bento/ubuntu-22.04` e iniciará automáticamente el aprovisionamiento de las 3 máquinas.*

---

## 🧪 Pruebas y Validación de Requerimientos

### 1. Verificación del Clúster Consul (Pregunta 1)
- Ingresa a la interfaz web de Consul:
  👉 **`http://192.168.100.20:8500`**
- En **Nodes** deben aparecer los 3 nodos: `haproxy-node`, `web1-node` y `web2-node`.
- En **Services** debe aparecer el servicio `web` con los checks en verde.

### 2. Balanceo de Carga y Estadísticas de HAProxy (Pregunta 3)
- Accede a la aplicación web a través del balanceador:
  👉 **`http://192.168.100.20/`**
  *(Al refrescar repetidamente la página, verás cómo se alternan las respuestas entre `web1-node` y `web2-node`).*
- Accede al panel de estadísticas de HAProxy:
  👉 **`http://192.168.100.20:8404/stats`**

### 3. Demostración de Escalabilidad en Caliente (Pregunta 3 - Requisito 1)
Entra por SSH a uno de los nodos web (por ejemplo, `web1`):
```bash
vagrant ssh web1
```
Ejecuta el script de escalabilidad para levantar 3 instancias:
```bash
cd /home/vagrant/app
bash scale.sh 3
```
*Al revisar el panel de estadísticas de HAProxy (`:8404/stats`), verás que se agregan automáticamente las 3 instancias en puertos 3000, 3001 y 3002 sin necesidad de reiniciar HAProxy.*

### 4. Prueba de Indisponibilidad / Error 503 Personalizado (Pregunta 3 - Requisito 2)
Apaga los nodos de backend para simular la caída total del servicio:
```bash
vagrant halt web1 web2
```
Ingresa a `http://192.168.100.20/` y observarás la página personalizada:
*"⚠️ Lo sentimos, servicio no disponible"*.

Vuelve a encenderlos con:
```bash
vagrant up web1 web2
```

### 5. Pruebas de Carga con Artillery (Pregunta 3 - Requisito 3)
En la máquina anfitriona (con Node.js instalado), ejecuta:
```bash
# Ejecutar las 3 fases de carga
npx artillery run artillery.yml

# (Opcional) Generar reporte gráfico en HTML
npx artillery run --output report.json artillery.yml
npx artillery report report.json
```
*Durante la prueba, observa cómo se comportan las métricas de concurrencia y tiempos de respuesta (P95 / P99) en el panel de HAProxy.*

---

## 🛠️ Guía Rápida de Comandos para la Sustentación (Cheat-Sheet)

Si el evaluador te solicita consultar o modificar el estado del sistema en caliente, utiliza estos comandos:

### 1. 🔍 Consultas del Clúster y Catálogo Consul (Pregunta 1)
```bash
# Ver miembros del clúster (nodos vivos y modo server/client)
vagrant ssh haproxy -c "consul members"

# Ver detalles completos de los miembros (direcciones, datacenter, tags)
vagrant ssh haproxy -c "consul members -detailed"

# Ver quién es el nodo Líder del consenso Raft
vagrant ssh haproxy -c "curl -s http://localhost:8500/v1/status/leader"

# Ver lista de peers que participan en el quórum
vagrant ssh haproxy -c "curl -s http://localhost:8500/v1/status/peers"

# Ver todos los servicios registrados en el catálogo
vagrant ssh haproxy -c "curl -s http://localhost:8500/v1/catalog/services"

# Ver instancias activas del servicio 'web'
vagrant ssh haproxy -c "curl -s http://localhost:8500/v1/catalog/service/web"

# Ver el estado de todos los Health Checks (Passing vs Critical)
vagrant ssh haproxy -c "curl -s http://localhost:8500/v1/health/service/web | jq '.[].Checks[] | {Node: .Node, CheckID: .CheckID, Status: .Status, Output: .Output}'"
```

### 2. ⚖️ Consultas del Balanceador HAProxy y Consul-Template (Preguntas 2 y 3)
```bash
# Ver la configuración generada en caliente por Consul-Template
vagrant ssh haproxy -c "cat /etc/haproxy/haproxy.cfg"

# Ver la plantilla Go/Jinja de Consul-Template
vagrant ssh haproxy -c "cat /etc/consul-template.d/haproxy.ctmpl"

# Ver los logs en vivo de Consul-Template (para evidenciar recargas automáticas)
vagrant ssh haproxy -c "journalctl -u consul-template -n 25 --no-pager"

# Ver métricas internas de HAProxy por socket administrativo
vagrant ssh haproxy -c "echo 'show info' | sudo socat stdio /run/haproxy/admin.sock"

# Ver estado de los servidores backend por socket administrativo
vagrant ssh haproxy -c "echo 'show stat' | sudo socat stdio /run/haproxy/admin.sock"

# Probar alternancia Round-Robin rápida desde terminal (4 peticiones)
vagrant ssh haproxy -c "for i in {1..4}; do curl -s http://localhost/ | grep -E 'Servidor:|Puerto Local:'; done"
```

### 3. 📦 Gestión de Procesos PM2 y Nodos Backend (Pregunta 3)
```bash
# Ver lista de procesos y consumo de recursos en web1 o web2
vagrant ssh web1 -c "pm2 list"

# Ver logs de la aplicación Express en web1
vagrant ssh web1 -c "pm2 logs --lines 20 --nostream"

# Probar el endpoint de Health Check localmente en una instancia
vagrant ssh web1 -c "curl -i http://localhost:3000/health"

# Escalar en caliente a N instancias (ejemplo: 4 instancias)
vagrant ssh web1 -c "cd /home/vagrant/app && bash scale.sh 4"

# Reducir a 1 sola instancia (limpieza limpia de registros)
vagrant ssh web1 -c "cd /home/vagrant/app && bash scale.sh 1"
```

### 4. 💥 Pruebas de Fallo / Tolerancia a Caídas en Vivo
```bash
# Detener una sola instancia específica (ej. puerto 3001) para ver cómo HAProxy la aísla
vagrant ssh web1 -c "pm2 stop web-web1-node-3001"

# Reiniciar la instancia caída
vagrant ssh web1 -c "pm2 restart web-web1-node-3001"

# Simular caída total para forzar el error 503
vagrant ssh web1 -c "pm2 stop all"
vagrant ssh web2 -c "pm2 stop all"

# Reactivar todos los servidores
vagrant ssh web1 -c "cd /home/vagrant/app && bash scale.sh 1"
vagrant ssh web2 -c "cd /home/vagrant/app && bash scale.sh 1"
```
